<?php include 'includes/header.php';?>

<section class="rightContent_wrapper inbox-section-wrapper">
    <div class="inbox-content">
        <div class="chatLeft">
            <div class="property_Owner_detail">
                <div class="ownerImg">
                    <img src="assets/images/owner-img.png" alt="">
                </div>
                <div class="owner_desc">
                    <p class="title">Martin Joseph</p>
                    <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium.</p>
                </div>
                <div class="chat-time-msg">
                    <small>20 mins</small>
                    <span>20</span>
                </div>
            </div>
            <div class="property_Owner_detail">
                <div class="ownerImg">
                    <img src="assets/images/owner-img.png" alt="">
                </div>
                <div class="owner_desc">
                    <p class="title">John Doe</p>
                    <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium.</p>
                </div>
                <div class="chat-time-msg">
                    <small>20 mins</small>
                    <span>20</span>
                </div>
            </div>
            <div class="property_Owner_detail">
                <div class="ownerImg">
                    <img src="assets/images/owner-img.png" alt="">
                </div>
                <div class="owner_desc">
                    <p class="title">Martin Joseph</p>
                    <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium.</p>
                </div>
                <div class="chat-time-msg">
                    <small>20 mins</small>
                    <span>20</span>
                </div>
            </div>
            <div class="property_Owner_detail">
                <div class="ownerImg">
                    <img src="assets/images/owner-img.png" alt="">
                </div>
                <div class="owner_desc">
                    <p class="title">Martin Joseph</p>
                    <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium.</p>
                </div>
                <div class="chat-time-msg">
                    <small>20 mins</small>
                    <span>20</span>
                </div>
            </div>
            <div class="property_Owner_detail">
                <div class="ownerImg">
                    <img src="assets/images/owner-img.png" alt="">
                </div>
                <div class="owner_desc">
                    <p class="title">Martin Joseph</p>
                    <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium.</p>
                </div>
                <div class="chat-time-msg">
                    <small>20 mins</small>
                    <span>20</span>
                </div>
            </div>
            <div class="property_Owner_detail">
                <div class="ownerImg">
                    <img src="assets/images/owner-img.png" alt="">
                </div>
                <div class="owner_desc">
                    <p class="title">Martin Joseph</p>
                    <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium.</p>
                </div>
                <div class="chat-time-msg">
                    <small>20 mins</small>
                    <span>20</span>
                </div>
            </div>
            <div class="property_Owner_detail">
                <div class="ownerImg">
                    <img src="assets/images/owner-img.png" alt="">
                </div>
                <div class="owner_desc">
                    <p class="title">Martin Joseph</p>
                    <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium.</p>
                </div>
                <div class="chat-time-msg">
                    <small>20 mins</small>
                    <span>20</span>
                </div>
            </div>
            <div class="property_Owner_detail">
                <div class="ownerImg">
                    <img src="assets/images/owner-img.png" alt="">
                </div>
                <div class="owner_desc">
                    <p class="title">Martin Joseph</p>
                    <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium.</p>
                </div>
                <div class="chat-time-msg">
                    <small>20 mins</small>
                    <span>20</span>
                </div>
            </div>
            <div class="property_Owner_detail">
                <div class="ownerImg">
                    <img src="assets/images/owner-img.png" alt="">
                </div>
                <div class="owner_desc">
                    <p class="title">John Smith</p>
                    <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium.</p>
                </div>
                <div class="chat-time-msg">
                    <small>20 mins</small>
                    <span>20</span>
                </div>
            </div>
        </div>
        <div class="chatRight">
            <div class="chatHeader_title">
                <p class="title">Martin Joseph</p>
            </div>
            <div class="user_msg_detail">
                <div class="msgRecieved">
                    <div class="userImg">
                        <img src="assets/images/owner-img.png" alt="">
                    </div>
                    <div class="user_msg_desc_bg">
                        <p class="semiBold">Martin Joseph</p>
                        <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium, mattis duis posuere.</p>
                    </div>
                    <small>15 mins</small>
                </div>
                <div class="msgsent">
                    <small>15 mins</small>
                    <div class="user_msg_desc_bg">
                        <p class="semiBold">Martin Joseph</p>
                        <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium, mattis duis posuere.</p>
                    </div>
                    <div class="userImg">
                        <img src="assets/images/owner-img.png" alt="">
                    </div>
                </div>
                <div class="msgRecieved">
                    <div class="userImg">
                        <img src="assets/images/owner-img.png" alt="">
                    </div>
                    <div class="user_msg_desc_bg">
                        <p class="semiBold">Martin Joseph</p>
                        <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium, mattis duis posuere.</p>
                    </div>
                    <small>15 mins</small>
                </div>
                <div class="msgsent">
                    <small>15 mins</small>
                    <div class="user_msg_desc_bg">
                        <p class="semiBold">Martin Joseph</p>
                        <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium, mattis duis posuere.</p>
                    </div>
                    <div class="userImg">
                        <img src="assets/images/owner-img.png" alt="">
                    </div>
                </div>
                <div class="msgRecieved">
                    <div class="userImg">
                        <img src="assets/images/owner-img.png" alt="">
                    </div>
                    <div class="user_msg_desc_bg">
                        <p class="semiBold">Martin Joseph</p>
                        <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium, mattis duis posuere.</p>
                    </div>
                    <small>15 mins</small>
                </div>
                <div class="msgsent">
                    <small>15 mins</small>
                    <div class="user_msg_desc_bg">
                        <p class="semiBold">Martin Joseph</p>
                        <p class="paragraph">Lorem ipsum dolor sit amet consectetur adipiscing elit pretium, mattis duis posuere.</p>
                    </div>
                    <div class="userImg">
                        <img src="assets/images/owner-img.png" alt="">
                    </div>
                </div>
            </div>
            <div class="chatFooter">
                <input type="text" placeholder="Type your message...">
                <div class="emojisBtn">
                    <a href="javascript:void(0)">
                        <img src="assets/images/smile.png" alt="">
                    </a>
                </div>
                <div class="sendMsg">
                    <a href="javascript:void(0)">
                        <img src="assets/images/paper-plane.png" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer-links.php';?>